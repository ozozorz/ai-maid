package io.github.ozozorz.aimaid.experiment;

import io.github.ozozorz.aimaid.llm.config.LlmConfigLoader;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

/** Explicit opt-in real-provider pilot: twenty cases, one paired A/B repeat, unchanged scoring. */
public final class RealLlmPilotGameTest implements FabricClientGameTest {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger("real-llm-pilot");

    @Override public void runTest(ClientGameTestContext context) {
        String configPath = System.getProperty("aimaid.experiment.realPilotConfig", "");
        String outputPath = System.getProperty("aimaid.experiment.realPilotOutput", "");
        if (configPath.isBlank() && outputPath.isBlank()) {
            LOGGER.info("Real LLM pilot skipped: explicit configuration and output paths are required.");
            return;
        }
        if (configPath.isBlank() || outputPath.isBlank())
            throw new IllegalArgumentException("Both realPilotConfig and realPilotOutput are required");
        var configFile = Path.of(configPath).toAbsolutePath();
        var output = Path.of(outputPath).toAbsolutePath();
        if (!Files.isRegularFile(configFile) || Files.exists(output.resolve("manifest.json")))
            throw new IllegalArgumentException("Pilot requires an existing configuration and unused output session");

        var active = new AtomicReference<ExperimentRunner>();
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            var runner = active.get();
            if (runner != null) runner.tick();
        });
        try {
            var config = LlmConfigLoader.load(configFile)
                    .orElseThrow(() -> new IllegalArgumentException("Real LLM is disabled"));
            try (var world = context.worldBuilder().create()) {
                var server = world.getServer();
                var connection = world.getConnection();
                connection.waitForChunksRender();
                long seed = 20261020L;
                var schedule = ExperimentCases.schedule(ExperimentCases.ALL, 1, seed, null);
                if (schedule.size() != 40) throw new AssertionError("Pilot must contain exactly 40 trials");
                var runner = server.computeOnServer(s -> new ExperimentRunner(s, connection.getServerPlayer(), config,
                        schedule, seed, ExperimentRunner.DEFAULT_SECONDS, output, LOGGER::info));
                active.set(runner);
                try {
                    // The runner owns each 300-second deadline. This wait only bounds the whole batch.
                    server.waitFor(s -> runner.done(), 300000);
                    var rows = server.computeOnServer(s -> runner.results());
                    if (rows.size() != 40 || rows.stream().anyMatch(row -> row.get("interrupted").getAsBoolean()))
                        throw new AssertionError("Pilot interrupted: " + runner.status());
                    LOGGER.info("Real LLM pilot completed: 40 trials. Evidence: {}", output);
                } finally {
                    server.runOnServer(s -> { if (!runner.done()) runner.stop("pilot_driver_stopped"); });
                    active.set(null);
                }
            }
        } catch (Exception e) {
            throw new AssertionError("Real LLM pilot could not complete", e);
        } finally {
            active.set(null);
        }
    }
}
