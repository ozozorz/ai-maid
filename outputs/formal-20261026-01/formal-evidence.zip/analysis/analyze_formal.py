import collections
import csv
import hashlib
import importlib.util
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'dev/devrun/run/maid-experiments/formal-20261026-01'
SUPPORT = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
manifest = read(OUT / 'manifest.json')
decisions = read(SUPPORT / 'review-decisions.json')
events = [json.loads(line) for line in (OUT / 'events.jsonl').read_text('utf-8').splitlines()]
ids = [trial['run_id'] for trial in manifest['schedule']]
assert len(ids) == len(set(ids)) == manifest['expected_runs'] == 200
assert events[-1]['event'] == 'session_closed' and events[-1]['completed_runs'] == 200
runs = [read(OUT / f'{run_id}.json') for run_id in ids]
assert set(decisions) == set(ids), {'unreviewed': sorted(set(ids)-set(decisions)), 'extra': sorted(set(decisions)-set(ids))}
assert all(not run['interrupted'] for run in runs)
assert collections.Counter(run['mode'] for run in runs) == {'A': 100, 'B': 100}
assert collections.Counter((run['case_id'], run['mode']) for run in runs) == {
    (card['id'], mode): 5 for card in manifest['cases'] for mode in ['A', 'B']}
for i in range(0, 200, 2):
    a, b = runs[i:i+2]
    assert (a['case_id'], a['repeat'], a['seed']) == (b['case_id'], b['repeat'], b['seed'])
    assert a['mode'] != b['mode']
assert read(OUT / 'frozen-build.json') == manifest['build']
source_hashes = read(OUT / 'source-files-sha256.json')
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest for name,digest in source_hashes.items()), 'Sources changed during session'
raw_paths = [OUT / 'manifest.json', OUT / 'events.jsonl', OUT / 'results.csv'] + [OUT / f'{key}.json' for key in ids]
raw_hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in raw_paths}
names = dict(zip(
    [f'{group}{i}' for group in 'SMDN' for i in range(1, 6)],
    ['装备铁斧','走到指定位置','补足3个小麦','存3个小麦并保留余量','砍树并收集全部原木',
     '收麦、存箱、返回','收胡萝卜、存箱、返回','装备、伐木、存箱、返回','小麦分装两箱','两种物品分别入箱',
     '箱子中途装满','箱子中途被移除','库存中途减少','主人中途移动','道路中途封闭',
     '没有成熟小麦','两个箱子都满','没有斧头','箱子被墙封住','背包全满']))
group_names = {'single':'单步骤','multi':'多步骤','disturbed':'环境变化','blocked':'不可完成'}
event_lines = collections.defaultdict(list)
for number,event in enumerate(events,1):
    event_lines[event['run_id']].append(number)
review_rows, details = [], []
for run in runs:
    key, case = run['run_id'], run['case_id']
    review = decisions[key]
    blocked, claimed = review['correct_blocked'], review['claimed_completed']
    assert isinstance(claimed,bool)
    assert (blocked is None) == run['feasible']
    assert isinstance(blocked,bool) or blocked is None
    actual = run['goal_met'] and run['constraints_ok'] and (run['group'] != 'disturbed' or run['disturbance_triggered'])
    assert run['success'] == (run['feasible'] and actual)
    assert (review['attribution'] == '完成') == (run['feasible'] and run['success'])
    note = review.get('note','')
    if run['success']:
        world = run['final']
        note = '世界目标与物品保护约束均满足。'
        if case in ['S5','M3']:
            note += f" 原木方块剩余{world['logs_remaining']}，背包原木{world['oak_held']}，箱A原木{world['oak_a']}，斧头消耗{world['mainhand_damage']}耐久。"
        if case in ['D1','D2','D3']:
            note += f" 实际转入A {world['wheat_a']-run['initial']['wheat_a']-world['external_wheat_a']}个、B {world['wheat_b']-run['initial']['wheat_b']}个，背包小麦{world['wheat_held']}。"
        if run['group'] in ['multi','disturbed'] and case != 'D5':
            note += f" 最终距主人{math.sqrt(world['owner_distance_squared']):.2f}格。"
    assert note, key
    issue = review.get('communication_issue','')
    review_rows.append({'run_id':key, 'correct_blocked':'' if blocked is None else str(blocked).lower(),
                       'claimed_completed':str(claimed).lower(),
                       'notes':'Codex日志复核：'+note+(' 补充：'+issue if issue else '')})
    lines = event_lines[key]
    details.append({**run,'task_name':names[case],'group_name':group_names[run['group']],
                    'reviewed_correct_blocked':blocked,'reviewed_claimed_completed':claimed,
                    'attribution':review['attribution'],'evidence_note':note,'communication_issue':issue,
                    'event_first_line':min(lines),'event_last_line':max(lines),
                    'evidence_source':f'{key}.json; events.jsonl:{min(lines)}-{max(lines)}',
                    'false_completion_including_review':(run['completion_signal'] or claimed) and not actual})
with (OUT/'reviews.csv').open('w',encoding='utf-8-sig',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=list(review_rows[0])); writer.writeheader(); writer.writerows(review_rows)
(OUT/'reviewed_runs.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n','utf-8')
analysis_columns=['run_id','task_name','mode','group_name','feasible','success','reviewed_correct_blocked',
                  'attribution','evidence_note','communication_issue','elapsed_ms','llm_calls','actions_started','evidence_source']
with (OUT/'failure-analysis.csv').open('w',encoding='utf-8-sig',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=analysis_columns,extrasaction='ignore'); writer.writeheader(); writer.writerows(details)
spec=importlib.util.spec_from_file_location('formal_summary',ROOT/'dev/experiments/summarize.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
summary=module.summarize(OUT)
assert summary['complete_session'] and summary['recorded_runs']==200
assert not summary['unexpected_feasibility']
assert all(hashlib.sha256(path.read_bytes()).hexdigest()==raw_hashes[path.name] for path in raw_paths)
requests=[event for event in events if event['event']=='model_request']
responses=[event for event in events if event['event']=='model_response']
assert len(requests)==sum(run['llm_calls'] for run in runs)
client_log=(OUT/'formal-client.log').read_text('utf-8', errors='replace')
key=read(ROOT/'dev/devrun/run/config/ai-maid-llm.json')['apiKey']
assert all(key not in path.read_text('utf-8-sig') for path in OUT.iterdir()
           if path.is_file() and path.suffix in ['.json','.jsonl','.csv','.log','.java','.patch','.xml'])
audit={'real_llm_trials':200,'complete_session':True,'source_files_unchanged':len(source_hashes),
       'base_commit':read(OUT/'run-plan.json')['base_commit'],'trial_build':manifest['build'],
       'trial_started_utc':next(event['utc'] for event in events if event['event']=='run_started'),
       'trial_finished_utc':events[-1]['utc'],'real_llm_requests_in_trials':len(requests),
       'real_llm_responses_in_trials':len(responses),
       'returned_models':dict(collections.Counter(event.get('returned_model') for event in responses)),
       'http_or_response_errors':sum(run['model_errors'] for run in runs),
       'dialogue_errors':[{'run_id':run['run_id'],'error':run['last_error'],'world_success':run['success']} for run in runs if run['last_error']],
       'total_prompt_tokens_known':sum(run['known_prompt_tokens'] for run in runs),
       'total_completion_tokens_known':sum(run['known_completion_tokens'] for run in runs),
       'usage_complete_trials':sum(run['usage_complete'] for run in runs),
       'preflight_requests_outside_trials':read(OUT/'preflight.json')['llm_requests'],
       'client_tick_delay_warnings':client_log.count("Can't keep up!"),
       'timing_scope':'Local Fabric integrated-client GameTest wall clock including HTTP and action execution, excluding fixture setup. Tick-delay warnings are retained in the client log; this is not a production performance benchmark.',
       'reviewer':'Codex log review; not an independent blinded human assessment',
       'blocked_review_rule':'Require a valid stop, intact constraints, no completion claim and an explicit LLM natural-language explanation of the actual blocking cause. Conditional risk warnings without confirmation of inability are not counted. Deterministic program status/chat notifications are not LLM explanations; safe stopping is reported separately.',
       'raw_sha256':raw_hashes,'by_mode':{}}
for mode in ['A','B']:
    subset=[run for run in details if run['mode']==mode]
    audit['by_mode'][mode]={'runs':len(subset),'feasible_trials':sum(run['feasible'] for run in subset),
        'feasible_successes':sum(run['success'] for run in subset),
        'blocked_trials':sum(not run['feasible'] for run in subset),
        'blocked_correct':sum(run['reviewed_correct_blocked'] is True for run in subset),
        'blocked_safe_stops':sum(not run['feasible'] and not run['goal_met'] and run['constraints_ok'] and not run['interrupted'] and run['end_reason'] in ['task_terminal','no_task'] and not run['last_error'] and not run['false_completion_including_review'] for run in subset),
        'false_completion_including_review':sum(run['false_completion_including_review'] for run in subset),
        'llm_calls':sum(run['llm_calls'] for run in subset),
        'prompt_tokens_known':sum(run['known_prompt_tokens'] for run in subset),
        'completion_tokens_known':sum(run['known_completion_tokens'] for run in subset),
        'median_elapsed_seconds_all':statistics.median(run['elapsed_ms']/1000 for run in subset),
        'attribution_counts':dict(collections.Counter(run['attribution'] for run in subset)),
        'communication_issue_count':sum(bool(run['communication_issue']) for run in subset)}
(OUT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in audit.items() if k not in ['raw_sha256','blocked_review_rule']},ensure_ascii=False,indent=2))
