import hashlib
import io
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SUPPORT = Path(__file__).resolve().parent
SESSION = ROOT / 'dev/devrun/run/maid-experiments/formal-20261026-01'
OUTPUT = ROOT / 'outputs/formal-20261026-01'
read = lambda p: json.loads(p.read_text('utf-8'))
audit = read(SESSION / 'audit.json')
assert audit['real_llm_trials'] == 200 and audit['complete_session']
assert (SESSION / 'formal-client.log').is_file()
assert (OUTPUT / 'maid-formal-200.xlsx').is_file()
for name, digest in audit['raw_sha256'].items():
    assert hashlib.sha256((SESSION/name).read_bytes()).hexdigest() == digest, name
for name, digest in read(SESSION/'source-files-sha256.json').items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name

key = read(ROOT/'dev/devrun/run/config/ai-maid-llm.json')['apiKey'].encode('utf-8')
def check_content(name, payload):
    assert key and key not in payload, f'Credential found in {name}'
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            for item in archive.infolist():
                if not item.is_dir():
                    check_content(name+'/'+item.filename, archive.read(item))

files = [(path, 'session/'+path.name) for path in SESSION.iterdir() if path.is_file()]
files += [(SUPPORT/name, 'analysis/'+name) for name in [
    'analyze_formal.py','build_workbook.mjs','inspect_formal.py',
    'review-decisions.json','package_evidence.py']]
files += [(ROOT/'dev/experiments/summarize.py','analysis/summarize.py')]
for path, name in files:
    check_content(name, path.read_bytes())
OUTPUT.mkdir(parents=True, exist_ok=True)
archive_path = OUTPUT/'formal-evidence.zip'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path, name in sorted(files, key=lambda entry: entry[1]):
        archive.write(path, name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert sum(name.startswith('session/') and name.endswith('.json') and name.split('/')[-1].split('-')[0] in
               [group+str(i) for group in 'SMDN' for i in range(1,6)] for name in archive.namelist()) == 200
for name in ['summary.csv','per_case.csv','paired.csv','failure-analysis.csv','audit.json']:
    shutil.copy2(SESSION/name, OUTPUT/name)
checksums = {path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in OUTPUT.iterdir()
             if path.is_file() and path.name != 'SHA256.json'}
(OUTPUT/'SHA256.json').write_text(json.dumps(checksums, ensure_ascii=False, indent=2)+'\n','utf-8')
print(json.dumps({'archive':str(archive_path),'archive_bytes':archive_path.stat().st_size,
                  'archive_files':len(files),'raw_trials':200,'credential_scan':'passed'},ensure_ascii=False))
