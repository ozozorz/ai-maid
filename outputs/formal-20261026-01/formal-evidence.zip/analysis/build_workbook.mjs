import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const support=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(support,'../..');
const session=path.join(root,'dev/devrun/run/maid-experiments/formal-20261026-01');
const out=path.join(root,'outputs/formal-20261026-01');
const read=async name=>JSON.parse(await fs.readFile(path.join(session,name),'utf8'));
const runs=await read('reviewed_runs.json');
const audit=await read('audit.json');
const summary=await read('summary.json');
const manifest=await read('manifest.json');
if(runs.length!==200||!summary.complete_session)throw Error('Formal session is incomplete');
const wb=Workbook.create();
const overview=wb.worksheets.add('结果汇总');
const detail=wb.worksheets.add('逐次记录');
const font='Microsoft YaHei';
const blue='#263C59';
for(const sheet of [overview,detail])sheet.showGridLines=false;
const headers=['run_id','场景ID','场景','组别','类别','可完成 1/0','客观成功 1/0','受阻合格 1/0',
 '用时（秒）','LLM调用','实际动作','已知输入Token','已知输出Token','接口错误',
 '任务状态','任务原因','归因','日志复核','答复或结束状态问题','完成误信号 1/0',
 '中断 1/0','约束满足 1/0','扰动触发 1/0','证据定位','用量完整 1/0','答复或状态问题 1/0'];
const matrix=runs.map(r=>[r.run_id,r.case_id,r.task_name,r.mode,r.group_name,Number(r.feasible),Number(r.success),
 r.reviewed_correct_blocked===null?null:Number(r.reviewed_correct_blocked),r.elapsed_ms/1000,r.llm_calls,r.actions_started,
 r.known_prompt_tokens,r.known_completion_tokens,r.model_errors,r.task?.state??'无任务',r.task_reason,
 r.attribution,r.evidence_note,r.communication_issue,Number(r.false_completion_including_review),
 Number(r.interrupted),Number(r.constraints_ok),Number(r.disturbance_triggered),r.evidence_source,Number(r.usage_complete),null]);
detail.getRange('A1:Z201').values=[headers,...matrix];
detail.getRange('Z2:Z201').formulas=runs.map((r,i)=>[`=IF(LEN(S${i+2})>0,1,0)`]);
detail.getRange('A1:Z201').format.font={name:font,size:10,color:'#222222'};
detail.getRange('A1:Z201').format.verticalAlignment='center';
const widths={A:15,B:10,C:28,D:8,E:14,F:13,G:15,H:15,I:14,J:12,K:12,L:19,M:19,N:12,O:18,P:24,Q:19,R:70,S:70,T:20,U:12,V:15,W:15,X:50,Y:15,Z:20};
for(const [col,width]of Object.entries(widths))detail.getRange(`${col}1:${col}201`).format.columnWidth=width;
detail.getRange('A2:Z201').format.rowHeight=32;
for(const col of ['C','R','S','X'])detail.getRange(`${col}2:${col}201`).format.wrapText=true;
detail.getRange('F2:H201').setNumberFormat('0');
detail.getRange('I2:I201').setNumberFormat('0.00');
detail.getRange('J2:N201').setNumberFormat('#,##0');
detail.getRange('T2:W201').setNumberFormat('0');
detail.getRange('Y2:Z201').setNumberFormat('0');
detail.getRange('F2:N201').format.horizontalAlignment='right';
detail.getRange('T2:W201').format.horizontalAlignment='right';
detail.getRange('Y2:Z201').format.horizontalAlignment='right';
detail.tables.add('A1:Z201',true,'FormalRuns');
detail.getRange('A1:Z1').format={fill:blue,font:{name:font,size:10,bold:true,color:'#FFFFFF'},
 horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:34};
detail.getRange('A2:Z201').format.autofitRows();
detail.freezePanes.freezeRows(1); detail.freezePanes.freezeColumns(1);
detail.getRange('G2:G201').conditionalFormats.add('expression',{formula:'=AND($F2=1,$G2=0)',format:{fill:'#FCE8E6',font:{color:'#9C2525'}}});
detail.getRange('H2:H201').conditionalFormats.add('expression',{formula:'=AND($F2=0,$H2=0)',format:{fill:'#FFF2CC',font:{color:'#8A5B00'}}});
detail.getRange('S2:S201').conditionalFormats.add('expression',{formula:'=$S2<>""',format:{fill:'#FFF2CC',font:{color:'#8A5B00'}}});

overview.tabColor=blue;
overview.getRange('A1:G46').format.font={name:font,size:10,color:'#222222'};
overview.getRange('A1:G46').format.verticalAlignment='center';
overview.getRange('A1:G46').format.rowHeight=25;
for(const [col,width]of Object.entries({A:37,B:20,C:20,D:4,E:62,F:14,G:14}))overview.getRange(`${col}1:${col}46`).format.columnWidth=width;
overview.getRange('A2').values=[['女仆 AI：200 次正式实验']];
overview.getRange('A2').format.font={name:font,size:15,bold:true,color:blue};
overview.getRange('A3').values=[['2026-10-26　deepseek-flash　20 个场景，每个场景每组重复 5 次']];
overview.getRange('A3:G3').format.borders={bottom:{style:'thin',color:'#A9B4C2'}};
const header=(range,values)=>{overview.getRange(range).values=values;overview.getRange(range).format={fill:blue,font:{name:font,size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',rowHeight:30};};
header('A5:C5',[['指标','A：固定计划','B：逐步反馈']]);
const notes=[
 ['完成记录数','每组100次，失败样本全部保留。'],
 ['可完成任务数','每组75次；另有25次预设不可完成任务。'],
 ['客观完成数','由最终世界状态、物品约束和扰动是否触发判定。'],
 ['可完成任务成功率','客观完成数 ÷ 可完成任务数。'],
 ['单步骤完成数','每组25次。'],
 ['多步骤完成数','每组25次。'],
 ['环境变化完成数','每组25次，要求实际触发扰动。'],
 ['正确处理并说明受阻数','要求明确解释障碍、有效停止且无程序成功误信号。'],
 ['正确处理受阻率','正确处理并说明受阻数 ÷ 25；程序状态提示另记。'],
 ['完成信号与目标不符数','包括局部计划成功信号；不等同于LLM口头谎报。'],
 ['接口或响应错误数','来自实际请求日志，不含工具轮数限制。'],
 ['LLM调用总数','全部正式试次；另有1次连通检查不计入。'],
 ['已知Token总数','已知输入与输出合计，缓存输入也计入；不是费用。'],
 ['配对成功用时中位数（秒）',`仅比较双方都成功的${summary.pairs_both_success}对；包含HTTP和执行。`],
];
notes.forEach(([label,note],i)=>{overview.getRange(`A${i+6}`).values=[[label]];overview.getRange(`E${i+6}`).values=[[note]];});
const s="'逐次记录'!";
const paired=runs.filter(r=>r.feasible&&r.success&&runs.some(other=>other.case_id===r.case_id&&other.repeat===r.repeat&&other.mode!==r.mode&&other.success));
const median=v=>{const a=[...v].sort((x,y)=>x-y);return a.length%2?a[Math.floor(a.length/2)]:(a[a.length/2-1]+a[a.length/2])/2;};
for(const [col,mode]of [['B','A'],['C','B']]){
 const count=extra=>`=COUNTIFS(${s}$D$2:$D$201,"${mode}"${extra})`;
 const sum=target=>`SUMIFS(${s}$${target}$2:$${target}$201,${s}$D$2:$D$201,"${mode}")`;
 const formulas=[count(''),count(`,${s}$F$2:$F$201,1`),'='+sum('G'),`=${col}8/${col}7`,
  ...['单步骤','多步骤','环境变化'].map(group=>count(`,${s}$E$2:$E$201,"${group}",${s}$G$2:$G$201,1`)),
  '='+sum('H'),`=${col}13/COUNTIFS(${s}$D$2:$D$201,"${mode}",${s}$F$2:$F$201,0)`,
  '='+sum('T'),'='+sum('N'),'='+sum('J'),'='+sum('L')+'+'+sum('M')];
 formulas.forEach((formula,i)=>overview.getRange(`${col}${i+6}`).formulas=[[formula]]);
 overview.getRange(`${col}19`).values=[[median(paired.filter(r=>r.mode===mode).map(r=>r.elapsed_ms/1000))]];
}
overview.getRange('B6:C18').setNumberFormat('#,##0');
overview.getRange('B9:C9').setNumberFormat('0.0%');
overview.getRange('B14:C14').setNumberFormat('0.0%');
overview.getRange('B19:C19').setNumberFormat('0.00');
overview.getRange('B6:C19').format.horizontalAlignment='right';
header('A22:C22',[['可完成场景（各5次）','A完成数','B完成数']]);
const feasibleCases=manifest.cases.filter(c=>c.feasible);
const blockedCases=manifest.cases.filter(c=>!c.feasible);
for(const [i,card]of feasibleCases.entries()){
 const row=23+i;
 overview.getRange(`A${row}`).values=[[card.id+'　'+runs.find(r=>r.case_id===card.id).task_name]];
 for(const [col,mode]of [['B','A'],['C','B']])overview.getRange(`${col}${row}`).formulas=[[
  `=COUNTIFS(${s}$B$2:$B$201,LEFT($A${row},2),${s}$D$2:$D$201,"${mode}",${s}$G$2:$G$201,1)`]];
}
header('A40:C40',[['不可完成场景（各5次）','A受阻合格数','B受阻合格数']]);
for(const [i,card]of blockedCases.entries()){
 const row=41+i;
 overview.getRange(`A${row}`).values=[[card.id+'　'+runs.find(r=>r.case_id===card.id).task_name]];
 for(const [col,mode]of [['B','A'],['C','B']])overview.getRange(`${col}${row}`).formulas=[[
  `=COUNTIFS(${s}$B$2:$B$201,LEFT($A${row},2),${s}$D$2:$D$201,"${mode}",${s}$H$2:$H$201,1)`]];
}
header('E22:G22',[['可完成任务的失败归因','A','B']]);
for(const [i,label]of ['策略限制','模型决策错误','程序问题','接口或服务错误','待定位'].entries()){
 const row=23+i;
 overview.getRange(`E${row}`).values=[[label]];
 for(const [col,mode]of [['F','A'],['G','B']])overview.getRange(`${col}${row}`).formulas=[[
  `=COUNTIFS(${s}$D$2:$D$201,"${mode}",${s}$F$2:$F$201,1,${s}$G$2:$G$201,0,${s}$Q$2:$Q$201,$E${row})`]];
}
overview.getRange('E29').values=[['另记：发现答复或结束状态问题的试次']];
for(const [col,mode]of [['F','A'],['G','B']])overview.getRange(`${col}29`).formulas=[[
 `=SUMIFS(${s}$Z$2:$Z$201,${s}$D$2:$D$201,"${mode}")`]];
const method=[
 'A/B每对使用相同场景种子，场景对和组内顺序随机化。',
 '同场景重复5次，不等于200个彼此独立的新任务。',
 '每次上限300秒、8个动作；运行中未改判定或替换失败。',
 '模型参数与预实验一致，正式实验使用修复后的源码。',
 '受阻解释与归因由Codex按日志复核，尚未独立人工复核。',
 '仅条件式提醒“可能失败”且未确认不能完成，不计正确受阻。',
 '实际成功但模型误报受阻，仍计客观成功并另记解释问题。',
 `日志、逐次JSON、模型请求和冻结源码均随证据包保留。`,
 `Token用量记录完整的试次：${audit.usage_complete_trials}/200。`,
 `受阻且无成功误信号：A ${audit.by_mode.A.blocked_safe_stops}/25，B ${audit.by_mode.B.blocked_safe_stops}/25。`,
 '程序自动失败通知与LLM自然语言解释分开统计。',
 '用时来自本机GameTest；客户端日志含tick延迟提示。',
];
method.forEach((text,i)=>overview.getRange(`E${32+i}`).values=[[text]]);
overview.getRange('E32:G44').format.font={name:font,size:10,color:'#555555'};
overview.getRange('B23:C37').format.horizontalAlignment='right';
overview.getRange('B41:C45').format.horizontalAlignment='right';
overview.getRange('F23:G29').format.horizontalAlignment='right';
wb.recalculate();
for(const [col,mode]of [['B','A'],['C','B']]){
 const a=audit.by_mode[mode];
 for(const [row,expected]of [[6,100],[7,75],[8,a.feasible_successes],[9,a.feasible_successes/75],
 [13,a.blocked_correct],[14,a.blocked_correct/25],[15,a.false_completion_including_review],[17,a.llm_calls],
 [18,a.prompt_tokens_known+a.completion_tokens_known]]){
  const actual=overview.getRange(`${col}${row}`).values[0][0];
  if(typeof actual!=='number'||!Number.isFinite(actual)||Math.abs(actual-expected)>1e-9)throw Error(`Summary mismatch ${col}${row}: ${actual} != ${expected}`);
 }
 if(overview.getRange(`${col}8`).values[0][0]!==summary.groups.find(g=>g.mode===mode&&g.group==='feasible_all').successes)throw Error('Raw summary mismatch');
 for(const [row,group]of [[10,'single'],[11,'multi'],[12,'disturbed']]){
  if(overview.getRange(`${col}${row}`).values[0][0]!==summary.groups.find(g=>g.mode===mode&&g.group===group).successes)throw Error('Group summary mismatch');
 }
 const issueCol=mode==='A'?'F':'G';
 if(overview.getRange(`${issueCol}29`).values[0][0]!==a.communication_issue_count)throw Error('Issue-count mismatch');
}
for(const [cases,start,field]of [[feasibleCases,23,'success'],[blockedCases,41,'reviewed_correct_blocked']]){
 for(const [i,card]of cases.entries())for(const [col,mode]of [['B','A'],['C','B']]){
  const expected=runs.filter(r=>r.case_id===card.id&&r.mode===mode&&r[field]).length;
  if(overview.getRange(`${col}${start+i}`).values[0][0]!==expected)throw Error(`Case count mismatch ${card.id}/${mode}`);
 }
}
// Verify dependent counts on a disposable in-memory change, then restore the observation.
const index=runs.findIndex(r=>r.mode==='A'&&r.success);
const cell=`G${index+2}`;
detail.getRange(cell).values=[[0]]; wb.recalculate();
if(overview.getRange('B8').values[0][0]!==audit.by_mode.A.feasible_successes-1)throw Error('Recalculation failed');
detail.getRange(cell).values=[[1]]; wb.recalculate();
if(overview.getRange('B8').values[0][0]!==audit.by_mode.A.feasible_successes)throw Error('Observation restore failed');
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:30},maxChars:2000})).ndjson);
console.log((await wb.inspect({kind:'table',range:'结果汇总!A5:C19',include:'values,formulas',tableMaxRows:15,tableMaxCols:3,maxChars:3500})).ndjson);
for(const [sheetName,range,name]of [['结果汇总','A1:G46','summary-preview.png'],['逐次记录','A1:K8','records-preview.png'],['逐次记录','Q8:T11','notes-preview.png'],['逐次记录','Q156:T157','anomaly-preview.png']]){
 const preview=await wb.render({sheetName,range,scale:1.3,format:'png'});
 await fs.writeFile(path.join(support,name),new Uint8Array(await preview.arrayBuffer()));
}
await fs.mkdir(out,{recursive:true});
await(await SpreadsheetFile.exportXlsx(wb)).save(path.join(out,'maid-formal-200.xlsx'));
console.log(JSON.stringify({file:path.join(out,'maid-formal-200.xlsx'),records:runs.length}));
