import argparse
import collections
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SESSION = ROOT / 'dev/devrun/run/maid-experiments/formal-20261026-01'

parser = argparse.ArgumentParser()
parser.add_argument('--after', type=int, default=0)
parser.add_argument('--limit', type=int, default=20)
parser.add_argument('--review', action='store_true')
parser.add_argument('--events', nargs='*')
args = parser.parse_args()
manifest = json.loads((SESSION / 'manifest.json').read_text('utf-8'))
runs = []
for trial in manifest['schedule']:
    file = SESSION / (trial['run_id'] + '.json')
    if file.exists():
        try:
            runs.append(json.loads(file.read_text('utf-8')))
        except json.JSONDecodeError:
            pass  # The last result can be in the middle of an append-only write.
events = []
with (SESSION / 'events.jsonl').open(encoding='utf-8') as source:
    for number, line in enumerate(source, 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event['line'] = number
        events.append(event)
progress = {'completed': len(runs), 'expected': manifest['expected_runs'],
            'model_errors': sum(r['model_errors'] for r in runs),
            'interrupted': sum(r['interrupted'] for r in runs),
            'constraint_violations': sum(not r['constraints_ok'] for r in runs),
            'false_completion_signals': sum(r['false_completion_signal'] for r in runs),
            'latest': {k: events[-1].get(k) for k in ['utc', 'run_id', 'event']} if events else None,
            'by_mode': {}}
for mode in ['A', 'B']:
    subset = [r for r in runs if r['mode'] == mode]
    progress['by_mode'][mode] = {
        'completed': len(subset), 'feasible': sum(r['feasible'] for r in subset),
        'successes': sum(r['success'] for r in subset),
        'blocked': sum(not r['feasible'] for r in subset)}
print(json.dumps(progress, ensure_ascii=False))
if args.review:
    for index, run in enumerate(runs[args.after:args.after + args.limit], args.after + 1):
        view = {k: run.get(k) for k in ['run_id', 'case_id', 'mode', 'feasible', 'success',
                'goal_met', 'constraints_ok', 'task_reason', 'end_reason', 'last_error',
                'false_completion_signal', 'disturbance_triggered', 'elapsed_ms']}
        view['index'] = index
        view['dialogue'] = [{'kind': d['kind'], 'text': d['text']} for d in run['dialogue']
                            if d['kind'] in ['assistant', 'error']]
        view['steps'] = [{k: s.get(k) for k in ['action', 'state', 'reason', 'count', 'progress']}
                         for s in run.get('task', {}).get('steps', [])]
        view['world'] = {k: run['final'].get(k) for k in ['wheat_a', 'wheat_b', 'wheat_held',
                       'carrot_a', 'carrot_b', 'carrot_held', 'oak_a', 'oak_held', 'logs_remaining',
                       'mainhand_damage', 'owner_distance_squared', 'point_distance_squared',
                       'external_wheat_a', 'external_inventory_wheat']}
        print(json.dumps(view, ensure_ascii=False))
if args.events:
    for event in events:
        if event['run_id'] in args.events and event['event'] in ['model_response', 'model_error', 'tool_result', 'disturbance']:
            print(json.dumps(event, ensure_ascii=False))
